$('#trust-carousel').slick({
    infinite: true,
    dots: false,
    arrows: true,
    slidesToShow: 3,
    slidesToScroll: 3,
    accessibility: true,
    touchMove: true,
  });
  $(".navbar__toggler").on("click",function(){
    $('.collapse').toggleClass("show");
  });